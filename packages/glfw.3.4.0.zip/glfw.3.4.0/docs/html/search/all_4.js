var searchData=
[
  ['7_20framebuffer_20transparency_20requires_20dwm_20transparency_0',['Windows 7 framebuffer transparency requires DWM transparency',['../news.html#win7_framebuffer_caveat',1,'']]]
];
